Question 10b) was not completed due to time constraints and conflicting deadlines with other courses in my dual degree. Apologies.

10a) was completed and union-find was implemented using trees